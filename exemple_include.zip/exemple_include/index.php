<?php
require 'inc/header.inc.php';
require 'inc/nav.inc.php';
?>

			<section>
				<h1>Accueil</h1>
				<p>
				 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus in sem ut libero sodales accumsan. Nulla iaculis cursus massa in bibendum. Ut eget sapien nec felis vulputate vulputate vel at mi. Nam dapibus, est sit amet aliquet interdum, arcu sapien sagittis nibh, ac ornare risus leo vel ligula. Cras molestie sem vel ex varius elementum. Fusce nec dapibus tortor. Aliquam eu elit id augue molestie eleifend. Aenean vehicula elementum faucibus. Praesent ultrices egestas ultrices. Maecenas nunc dui, dignissim eu ex ac, posuere tempor neque.<br><br>

				Vestibulum vulputate pulvinar sem at tempor. Etiam vulputate, neque in dignissim consequat, leo nisi tincidunt dolor, id eleifend augue elit eu elit. Vestibulum hendrerit in nisi eget congue. Aliquam pharetra ligula felis, ut blandit enim porta eget. Curabitur et ipsum eu erat rhoncus dictum non eget mauris. Sed scelerisque, mi sit amet bibendum porttitor, lorem magna elementum quam, gravida sodales ligula tellus eget felis. Donec vitae magna consectetur, pulvinar augue at, ultricies leo. Pellentesque id quam id mauris ultrices pharetra sit amet eget justo. Phasellus eu rutrum velit. Quisque turpis odio, facilisis a odio id, facilisis fermentum leo. Sed libero orci, tempor ac dui in, sagittis gravida lorem.<br><br>

				Nullam congue, lorem vitae mollis pharetra, orci ex ultricies dolor, quis venenatis risus mi nec purus. Quisque non convallis nibh. Donec sed tempus ipsum. Morbi iaculis pulvinar ante ut finibus. Sed cursus, velit nec vehicula faucibus, libero enim feugiat metus, in maximus augue tellus a mi. Sed pharetra diam quis enim posuere, ut cursus lacus efficitur. Nunc sit amet felis ac tortor tempus commodo. Praesent interdum volutpat tincidunt. Sed euismod fringilla est, ac hendrerit est vestibulum sed. Vivamus sit amet tempus orci. Sed mollis nisl vitae malesuada laoreet. Donec accumsan dictum turpis quis vulputate. Mauris feugiat tellus vel risus pellentesque, id efficitur tellus faucibus. 
				</p>
			</section>
<?php
require 'inc/footer.inc.php';			