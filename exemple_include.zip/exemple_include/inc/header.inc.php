<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/style.css">
		<meta charset="utf-8">
	</head>
	
	<body>
		<div class="conteneur">
			<header>
				<h1>Mon projet</h1>
			</header>