			<nav>
				<a href="index.php">Accueil</a>
				<a href="boutique.php">Boutique</a>
				<a href="panier.php">Panier</a>
				<a href="profil.php">Profil</a>
				<a href="contact.php">Nous contacter</a>
			</nav>